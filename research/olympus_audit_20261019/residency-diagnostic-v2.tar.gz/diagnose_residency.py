#!/usr/bin/env python3
"""Frozen, artificial CPU ownership diagnostic; see protocol.json before executing.

Usage: /path/to/olympus/.venv/bin/python diagnose_residency.py --output /tmp/fresh-run
No repository imports, training, external data, network, GPU, or loader modifications.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import platform
import shutil
import signal
import struct
import subprocess
import sys
import time
import types
import weakref
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PROTOCOL_SHA = "d937e38dc7b3d3c32f0fcafecd2f65a98ed532b7e368ee8ff17cd495c2af7a25"
SOURCE_MANIFEST_SHA = "9385bf0f380cdd171d44c78b550b85f595616c9433b1fff23657fd44ebf29d3b"
FLOOR = 2 * 1024**3


class Blocked(RuntimeError):
    pass


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise RuntimeError(reason)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def frozen() -> tuple[dict[str, Any], dict[str, Path]]:
    require(sha(ROOT / "protocol.json") == PROTOCOL_SHA, "protocol digest mismatch")
    require(sha(ROOT / "SOURCE_MANIFEST.json") == SOURCE_MANIFEST_SHA,
            "source manifest digest mismatch")
    files = json.loads((ROOT / "SOURCE_MANIFEST.json").read_text())["files"]
    paths = {}
    for item in files:
        path = ROOT / item["path"]
        payload = path.read_bytes()
        blob = hashlib.sha1(f"blob {len(payload)}\0".encode() + payload).hexdigest()
        require(sha(path) == item["sha256"] and blob == item["git_blob"],
                f"source bytes changed: {item['repository_path']}")
        paths[item["role"]] = path
    return json.loads((ROOT / "protocol.json").read_text()), paths


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def cache_credit(current: Path, version: int) -> int:
    """Conservative available-memory estimate; keep raw cgroup usage in the receipt.

    Linux container working-set reporting discounts inactive file cache. We further
    subtract all potentially dirty, mapped, or shared bytes from that credit. Missing counters get
    no credit. This is an estimate, not a guarantee that reclamation is immediate.
    """
    path = current / "memory.stat"
    if not path.is_file():
        return 0
    stats = {
        key: int(value) for key, value in (line.split() for line in path.read_text().splitlines())
    }
    names = ("inactive_file", "file", "shmem", "file_mapped", "file_dirty", "file_writeback")
    if version == 1:
        names = (
            "total_inactive_file",
            "total_cache",
            "total_shmem",
            "total_mapped_file",
            "total_dirty",
            "total_writeback",
        )
    if not set(names).issubset(stats) or any(stats[key] < 0 for key in names):
        return 0
    inactive, cached, *unavailable = (stats[key] for key in names)
    return max(0, min(inactive, cached) - sum(unavailable))



def observe(governor: Any) -> dict[str, Any]:
    require(platform.system() == "Linux", "this protocol freezes Linux CPU execution")
    result = governor.memory_snapshot().as_dict()
    members = [line.split(":", 2) for line in Path("/proc/self/cgroup").read_text().splitlines()]
    groups = []
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        before, after = line.split(" - ", 1)
        fields, fs = before.split(), after.split()[0]
        if fs not in {"cgroup", "cgroup2"}:
            continue
        version = 2 if fs == "cgroup2" else 1
        for _, controllers, location in members:
            wrong_v1 = version == 1 and "memory" not in controllers.split(",")
            if (version == 2 and controllers) or wrong_v1:
                continue
            mount = Path(fields[4])
            try:
                current = mount / Path(location).relative_to(Path(fields[3]))
            except ValueError:
                continue
            while current == mount or mount in current.parents:
                names = ("memory.max", "memory.current") if version == 2 else (
                    "memory.limit_in_bytes", "memory.usage_in_bytes")
                if (current / names[0]).is_file():
                    raw = (current / names[0]).read_text().strip()
                    item = {"path": str(current), "limit_bytes": None if raw == "max" else int(raw),
                            "used_bytes": int((current / names[1]).read_text())}
                    item["raw_headroom_bytes"] = (None if item["limit_bytes"] is None else
                                                   item["limit_bytes"] - item["used_bytes"])
                    item["cache_credit_bytes"] = min(
                        item["used_bytes"], cache_credit(current, version))
                    if version == 2 and (current / "memory.swap.max").is_file():
                        raw = (current / "memory.swap.max").read_text().strip()
                        item.update(
                            swap_limit_bytes=None if raw == "max" else int(raw),
                            swap_used_bytes=int((current / "memory.swap.current").read_text()))
                    groups.append(item)
                if current == mount:
                    break
                current = current.parent
    require(bool(groups), "cannot observe Linux cgroup memory constraints")
    available = [result["available_bytes"]] + [
        max(0, g["limit_bytes"] - g["used_bytes"] + g["cache_credit_bytes"])
        for g in groups if g["limit_bytes"] is not None]
    return {**result, "cgroups": groups, "effective_available_bytes": min(available)}


def admit(snapshot: dict[str, Any]) -> None:
    swap_high = snapshot["swap_fraction"] > 0.9 or any(
        g.get("swap_limit_bytes") and g["swap_used_bytes"] / g["swap_limit_bytes"] > 0.9
        for g in snapshot["cgroups"])
    if snapshot["effective_available_bytes"] < FLOOR or swap_high:
        raise Blocked("less than 2 GiB effective available memory or swap above 90%")


def no_network(event: str, _arguments: Any) -> None:
    if event in {"socket.connect", "socket.bind", "socket.sendto", "socket.getaddrinfo"}:
        raise RuntimeError(f"network operation excluded by frozen protocol: {event}")


def execute(kind: str, out: Path, report: dict[str, Any], governor: Any, deadline: float) -> None:
    before = observe(governor)
    admit(before)
    start = time.monotonic()
    if start >= deadline:
        raise Blocked("aggregate wall-time budget exhausted")
    command = [sys.executable, str(Path(__file__).resolve()),
               "--worker", kind, "--output", str(out)]
    environment = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "HIP_VISIBLE_DEVICES": "",
                   "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
                   "NUMEXPR_NUM_THREADS": "1", "PYTHONHASHSEED": "2026101901"}
    failure, samples = None, [before]
    with ((out / f"{kind}.stdout").open("wb") as stdout,
          (out / f"{kind}.stderr").open("wb") as stderr):
        proc = subprocess.Popen(command, cwd=out, env=environment, stdout=stdout, stderr=stderr,
                                start_new_session=True)
        try:
            while True:
                pid, status, usage = os.wait4(proc.pid, os.WNOHANG)
                if pid:
                    break
                if time.monotonic() >= min(deadline, start + 30):
                    raise Blocked("fixed child or aggregate wall-time budget exhausted")
                samples.append(observe(governor))
                admit(samples[-1])
                time.sleep(0.2)
        except BaseException as error:
            failure = error
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            _, status, usage = os.wait4(proc.pid, 0)
        proc.returncode = os.waitstatus_to_exitcode(status)
    report["commands"].append({"command": command, "cwd": str(out), "exit_status": proc.returncode,
        "elapsed_seconds": time.monotonic() - start,
        "abort_reason": str(failure) if failure else None,
        "stdout": f"{kind}.stdout", "stderr": f"{kind}.stderr", "memory_samples": samples,
        "memory_after": observe(governor), "child_peak_rss_bytes": int(usage.ru_maxrss * 1024),
        "child_user_seconds": usage.ru_utime, "child_system_seconds": usage.ru_stime,
        "child_major_page_faults": usage.ru_majflt, "thread_environment": {
            key: environment[key] for key in (
                "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")}})
    save(out / "receipt.json", report)
    if failure:
        raise failure
    if proc.returncode == 3:
        raise Blocked(f"{kind} was blocked by its child resource admission")
    require(proc.returncode == 0, f"{kind} failed; inspect retained stdout/stderr")


def storage_snapshot(module: Any, store: Any) -> dict[str, Any]:
    def collect(pairs: Any) -> dict[tuple[int, int], list[str]]:
        found: dict[tuple[int, int], list[str]] = {}
        for name, tensor in pairs:
            if not tensor.is_meta:
                require(tensor.device.type == "cpu", "non-CPU storage observed")
                storage = tensor.untyped_storage()
                found.setdefault((storage.data_ptr(), storage.nbytes()), []).append(name)
        return found
    model = collect(list(module.named_parameters()) + list(module.named_buffers()))
    cached = collect((f"{shard}/{name}", tensor) for shard, tensors in store._cache.items()
                     for name, tensor in tensors.items())
    union = model.keys() | cached.keys()
    return {"model_bytes": sum(size for _, size in model),
            "cache_tensor_bytes": sum(size for _, size in cached),
            "union_bytes": sum(size for _, size in union), "unique_storage_count": len(union),
            "serialized_cache_bytes": store._cache_bytes,
            "storages": [{"data_ptr": ptr, "nbytes": size,
                          "model_names": model.get((ptr, size), []),
                          "cache_names": cached.get((ptr, size), [])}
                         for ptr, size in sorted(union)]}


def owner_refs(module: Any, store: Any, step: int) -> list[Any]:
    return [(step, f"parameter:{name}", weakref.ref(tensor))
            for name, tensor in module.named_parameters()
            if not tensor.is_meta] + [(step, f"cache:{shard}/{name}", weakref.ref(tensor))
            for shard, tensors in store._cache.items() for name, tensor in tensors.items()]


def worker(kind: str, out: Path, protocol: dict[str, Any], paths: dict[str, Path]) -> None:
    actual = {"python": platform.python_version(), "torch": importlib.metadata.version("torch"),
              "pydantic": importlib.metadata.version("pydantic")}
    require(all(actual[key] == protocol["runtime"][key] for key in actual),
            "frozen runtime mismatch")
    governor = load_module("frozen_governor", paths["resource_governor"])
    admit(observe(governor))
    import torch
    from torch import nn
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(protocol["fixture"]["seed"])
    require(torch.version.cuda is None and torch.version.hip is None,
            "CPU-only torch build required")
    subject_root = paths["subject"].parents[1]
    for name, path in (("olympus", subject_root), ("olympus.core", subject_root / "core"),
                       ("olympus.models", subject_root / "models")):
        namespace = types.ModuleType(name)
        namespace.__path__ = [str(path)]
        sys.modules[name] = namespace
    load_module("olympus.core.schemas", paths["schema_dependency"])
    lazy = load_module("olympus.models.spatiotemporal_lazy", paths["subject"])
    fixture, width = out / "fixture", protocol["fixture"]["width"]
    if kind == "fixture":
        fixture.mkdir()
        records = []
        for index in range(3):
            path = fixture / f"shard{index}.pt"
            weight = torch.eye(width, dtype=torch.float32, device="cpu") * (index + 1)
            torch.save({f"layer{index}.weight": weight}, path)
            bounds = lazy.SpatialBounds(minimum=(100 * index - 1, -1, -1),
                                        maximum=(100 * index + 1, 1, 1))
            records.append(lazy.parameter_shard_record(
                f"shard{index}", path, root=fixture, spatial=bounds))
        manifest = lazy.build_parameter_manifest(records, fixture / "manifest.json")
        sizes = [record.byte_count for record in records]
        budget = max(sizes)
        require(budget <= 100000 and 65536 <= budget < 131072 and 2 * min(sizes) > budget,
                "fixture cannot implement the frozen one-shard budget")
        require(sum(p.stat().st_size for p in fixture.iterdir()) <= 8 * 1024**2,
                "fixture size ceiling exceeded")
        save(out / "fixture.json", {"budget_bytes": budget, "manifest": manifest.model_dump(),
                                  "manifest_sha256": sha(fixture / "manifest.json"),
                                  "runtime": actual})
        print(json.dumps({"fixture": "complete", "budget_bytes": budget,
                          "runtime": actual}), flush=True)
        return
    description = json.loads((out / "fixture.json").read_text())
    require(sha(fixture / "manifest.json") == description["manifest_sha256"], "manifest changed")
    budget = description["budget_bytes"]
    store = lazy.SpatiotemporalParameterStore(fixture / "manifest.json", cache_budget_bytes=budget)
    module, watch = None, []
    result = {"arm": kind, "complete": False, "runtime": actual, "device": "cpu",
              "torch_threads": torch.get_num_threads(), "budget_bytes": budget, "steps": []}
    x = torch.arange(width, dtype=torch.float32, device="cpu").reshape(1, width) / width
    for step, index in enumerate(protocol["fixture"]["trace"]):
        admit(observe(governor))
        if kind == "recreated_module" or module is None:
            module = None
            gc.collect()
            module = nn.ModuleDict({f"layer{i}": nn.Linear(width, width, bias=False, device="meta")
                                    for i in range(3)})
        query = lazy.SpatiotemporalQuery(position=(100 * index, 0, 0), timestamp=step, resolution=1)
        plan = store.plan(query, budget_bytes=budget)
        require([shard.shard_id for shard in plan.shards] == [f"shard{index}"], "unexpected plan")
        assignment = store.materialize_module(module, plan)
        with torch.inference_mode():
            output = module[f"layer{index}"](x)
            expected = x * (index + 1)
            exact = torch.equal(output, expected)
            values = output.flatten().tolist()
            output_hash = hashlib.sha256(struct.pack(f"<{width}f", *values)).hexdigest()
        del output, expected
        watch.extend(owner_refs(module, store, step))
        gc.collect()
        measurement = storage_snapshot(module, store)
        prior_live = [label for born, label, ref in watch if born < step and ref() is not None]
        row = {"step": step, "shard_index": index, "output_exact": exact,
               "output_shape": [1, width],
               "output_values": values, "output_sha256": output_hash, "plan": plan.model_dump(),
               "assignment": assignment.model_dump(), "disk_loads": store.disk_loads,
               "prior_assignment_owner_refs_alive": prior_live, **measurement}
        result["steps"].append(row)
        save(out / f"{kind}.json", result)
        print(json.dumps(row, sort_keys=True), flush=True)
        require(exact and store.disk_loads == step + 1 and store._cache_bytes <= budget,
                "output, matched disk-load, or narrow cache contract failed")
    result["complete"] = True
    save(out / f"{kind}.json", result)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--worker", choices=("fixture", "persistent_module", "recreated_module"),
                        help=argparse.SUPPRESS)
    args = parser.parse_args()
    protocol, paths = frozen()
    sys.addaudithook(no_network)
    out = args.output.resolve()
    if args.worker:
        try:
            worker(args.worker, out, protocol, paths)
        except Blocked as error:
            save(out / f"{args.worker}.failure.json", {"outcome": "BLOCKED", "error": str(error)})
            print(str(error), file=sys.stderr)
            return 3
        return 0
    out.mkdir(parents=True, exist_ok=False)
    report = {"study_id": protocol["study_id"], "status": "STARTED", "commands": [],
              "started_at": datetime.now(UTC).isoformat(), "script_sha256": sha(Path(__file__)),
              "protocol_sha256": PROTOCOL_SHA, "source_manifest_sha256": SOURCE_MANIFEST_SHA,
              "invocation": [sys.executable, *sys.argv], "scope": protocol["scope"]}
    for name in ("protocol.json", "SOURCE_MANIFEST.json", "diagnose_residency.py", "PROTOCOL.md",
                 "RESOURCE_POLICY_ORIGIN.json", "FREEZE.json"):
        shutil.copy2(ROOT / name, out / name)
    shutil.copytree(ROOT / "source", out / "source")
    deadline = time.monotonic() + 90
    governor = load_module("frozen_governor", paths["resource_governor"])
    lock = governor.ResourceGovernor(Path(f"/tmp/olympus-{os.getuid()}.workload.lock"))
    try:
        try:
            report["resource_preflight"] = lock.acquire().as_dict()
            admit(observe(governor))
        except RuntimeError as error:
            raise Blocked(str(error)) from error
        for kind in ("fixture", "persistent_module", "recreated_module"):
            execute(kind, out, report, governor, deadline)
        arms = {name: json.loads((out / f"{name}.json").read_text())
                for name in ("persistent_module", "recreated_module")}
        require(all(arm["complete"] and len(arm["steps"]) == 6 for arm in arms.values()),
                "incomplete matrix")
        budget = arms["persistent_module"]["budget_bytes"]
        require(arms["recreated_module"]["budget_bytes"] == budget, "unequal arm budgets")
        peaks = {name: max(row["union_bytes"] for row in arm["steps"])
                 for name, arm in arms.items()}
        if peaks["recreated_module"] > budget:
            outcome = "INCONCLUSIVE"
        elif peaks["persistent_module"] > budget:
            outcome = "RESIDENCY_INTERPRETATION_FALSIFIED"
        else:
            outcome = "NOT_FALSIFIED_IN_BOUND"
        report.update(status="COMPLETED", outcome=outcome,
                      peak_live_storage_bytes=peaks, budget_bytes=budget)
    except Exception as error:
        report.update(status="STOPPED",
                      outcome="BLOCKED" if isinstance(error, Blocked) else "INVALID",
                      error=f"{type(error).__name__}: {error}")
    finally:
        lock.release()
        report["finished_at"] = datetime.now(UTC).isoformat()
        report["artifact_sha256"] = {str(p.relative_to(out)): sha(p) for p in sorted(out.rglob("*"))
                                      if p.is_file() and p.name != "receipt.json"}
        save(out / "receipt.json", report)
    print(json.dumps({"status": report["status"], "outcome": report["outcome"],
                      "receipt": str(out / "receipt.json")}), flush=True)
    return 0 if report["status"] == "COMPLETED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
